/**
 * 
 */
/**
 * 
 */
module SortAlgorithmVisualization {
	requires junit;
	requires java.desktop;
}